# 🎬 Optimus Player - IPTV Multiplataforma Premium

![Status](https://img.shields.io/badge/status-in%20development-yellow)
![Platform](https://img.shields.io/badge/platform-Android%20%7C%20iOS%20%7C%20Smart%20TV-blue)
![License](https://img.shields.io/badge/license-Private-red)

## 📌 Sobre o Projeto

**Optimus Player** é um aplicativo IPTV multiplataforma premium com sistema de licenciamento anual robusto e painel de revenda multi-nível.

### ✨ Características Principais

- 📱 **Multiplataforma:** Android, iOS, Samsung Tizen, LG webOS, Roku
- 🔐 **Licenciamento Anual:** Sistema de validação por MAC Address + Device ID
- 💼 **Painel de Revenda:** Sistema multi-nível com créditos de ativação
- 🎨 **Design Premium:** Interface moderna preto e amarelo
- 📺 **Player Completo:** EPG, Chromecast, Controle Parental
- 💳 **Pagamento Integrado:** Mercado Pago

---

## 🚀 Plataformas Suportadas

| Plataforma | Status | Versão |
|------------|--------|--------|
| Android (Phone/Tablet/TV Box) | 🔄 Em Desenvolvimento | - |
| Fire Stick / Mi Stick | 🔄 Em Desenvolvimento | - |
| Samsung Tizen (Smart TV) | ⏳ Planejado | - |
| LG webOS (Smart TV) | ⏳ Planejado | - |
| Roku | ⏳ Planejado | - |
| iOS (iPhone/iPad) | ⏳ Planejado | - |
| Apple TV | ⏳ Planejado | - |

---

## 📂 Estrutura do Projeto

```
optimus-player/
├── android/              # App Android (Kotlin + ExoPlayer)
├── backend/              # API Node.js + PostgreSQL
├── admin-panel/          # Painel Admin (React + Tailwind)
├── reseller-panel/       # Painel Revendedor (React + Tailwind)
├── tizen/                # App Samsung Tizen (HTML5/JS)
├── webos/                # App LG webOS (Enyo/React)
├── roku/                 # App Roku (BrightScript)
├── ios/                  # App iOS (Swift + SwiftUI)
├── docs/                 # Documentação completa
├── mockups/              # Designs e mockups
└── README.md
```

---

## 🎨 Design

**Paleta de Cores:**
- Preto: `#000000` / `#121212`
- Amarelo: `#FFD700` / `#FFC107`
- Cinza Escuro: `#1E1E1E`
- Branco: `#FFFFFF`

**Tipografia:**
- Títulos: Montserrat Bold / Poppins Bold
- Corpo: Roboto / Inter

---

## 🛠️ Stack Tecnológica

### Mobile
- **Android:** Kotlin, ExoPlayer, Material Design, Room Database, Google Cast SDK
- **iOS:** Swift, SwiftUI, AVPlayer, AVKit

### Backend
- **API:** Node.js (Express/NestJS)
- **Banco de Dados:** PostgreSQL
- **Autenticação:** JWT
- **Pagamento:** Mercado Pago SDK

### Painéis Web
- **Frontend:** React.js, TypeScript, Tailwind CSS
- **State:** React Context / Redux Toolkit
- **HTTP Client:** Axios

### Smart TVs
- **Tizen:** HTML5/CSS3/JavaScript
- **webOS:** Enyo Framework / React
- **Roku:** BrightScript + SceneGraph

---

## 📋 Fases de Desenvolvimento

### ✅ Fase 0: Pesquisa e Planejamento
- [ ] Análise de concorrentes (DuplexPlay, IBO, Bob, Cap Player)
- [ ] Decisão de stack tecnológica
- [ ] Plano de infraestrutura (VPS + CDN)
- [ ] Arquitetura de sistema

### 🔄 Fase 1: Mockups e Design
- [ ] Paleta de cores e tipografia
- [ ] Logo Optimus Player
- [ ] Mockups de todas as telas Android

### ⏳ Fase 2: App Android
- [ ] Player ExoPlayer + Chromecast
- [ ] Parser M3U/EPG
- [ ] Interface premium
- [ ] Controle parental

### ⏳ Fase 3: Backend + Painéis
- [ ] API de licenciamento
- [ ] Painel Admin
- [ ] Painel Revendedor
- [ ] Integração Mercado Pago

### ⏳ Fase 4: Smart TVs
- [ ] Samsung Tizen
- [ ] LG webOS
- [ ] Roku

### ⏳ Fase 5: iOS
- [ ] iPhone/iPad
- [ ] Apple TV

---

## 📖 Documentação

Toda a documentação do projeto está em `docs/`:

- **API.md** - Endpoints da API REST
- **DATABASE.md** - Schema do banco de dados
- **DEPLOYMENT.md** - Como fazer deploy
- **CHANGELOG.md** - Histórico de mudanças

---

## 🔐 Segurança

- Licenças validadas por MAC Address + Device ID
- Tokens JWT com expiração
- Senhas criptografadas (bcrypt)
- EncryptedSharedPreferences (Android)
- Keychain (iOS)

---

## 📄 Licença

Este projeto é **privado** e de propriedade exclusiva.

**© 2025 Optimus Player. Todos os direitos reservados.**

---

## 👨‍💻 Desenvolvimento

**Desenvolvido com IA de ponta usando prompt engineering profissional.**

**Repositório:** `vandersonbraz/optimus-player`
